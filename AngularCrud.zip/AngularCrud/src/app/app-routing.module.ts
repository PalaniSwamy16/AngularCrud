import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { ListEmployeeComponent } from './employees/list-employee.component';
import { CreateEmployeeComponent } from './employees/create-employee.component';

const routes: Routes = [
       { path: 'List', component: ListEmployeeComponent},
       { path: 'Create', component: CreateEmployeeComponent},
       { path: '', redirectTo: '/List' , pathMatch: 'full'}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
