import { Component, OnInit } from '@angular/core';
import {NgForm, FormsModule} from '@angular/forms';
import {Department} from '../models/Deparment.model';
import { BsDatepickerConfig} from 'ngx-bootstrap/datepicker';
import { Employee } from '../models/employee.model';

@Component ({
  selector: 'app-create-employee',
  templateUrl: './create-employee.component.html',
  styleUrls: ['./create-employee.component.css']
})
export class CreateEmployeeComponent implements OnInit {

  dateofbirth: Date = new Date(2019, 1, 26);

  employee: Employee = {
    id: null,
    name: null,
    gender: null,
    phoneNumber: null,
    contactPreference: null,
    email: '',
    department: null,
    isActive: null,
    photoPath: null,
    dateOfBirth: null
  };
   previewPhoto  = false;

  bsDatePickerConfig: Partial <BsDatepickerConfig>;

  departments: Department[] = [
    { id: 1 , name: 'Help Desk'},
    { id: 2 , name: 'HR' },
    { id: 3 , name: 'IT' },
    { id: 4 , name: 'Payroll' }
];

  constructor() {

    this.bsDatePickerConfig = Object.assign({},
      {
        containerClass: 'theme-dark-blue',
         showWeekNumbers: false,
         minDate: new Date(2019, 0, 1),
         maxDate: new Date(2019, 11, 31),
         dateInputFormat: 'DD/MM/YYYY'
        });
  }

     togglePhotopreview() {
       this.previewPhoto = !this.previewPhoto;
      }

  ngOnInit() {
  }
  onSubmit(empForm: NgForm): void {
    console.log(empForm.value);
  }
}
