import { Component, OnInit } from '@angular/core';
import { Employee } from '../models/employee.model';

@Component({
  /// selector: 'app-list-employee',
  templateUrl: './list-employee.component.html',
  styleUrls: ['./list-employee.component.css']
})
export class ListEmployeeComponent implements OnInit {

  employees: Employee[] = [
    {
      id: 1,
      name: 'Andrew',
      gender: 'Male',
      phoneNumber: 890746578,
      contactPreference: 'Email',
      email: 'Andrew@gmail.com',
      dateOfBirth: new Date('10/25/2019'),
      department: 'IT',
      isActive: true,
      photoPath: 'assets/images/kimya.png'
    },
    {
      id: 2,
      name: 'Shela',
      gender: 'Female',
      phoneNumber: 760746578,
      contactPreference: 'Email',
      email: 'Shela@gmail.com',
      dateOfBirth: new Date('01/02/2009'),
      department: 'IT',
      isActive: true,
      photoPath: 'assets/images/i_bookmark.png'
    }
  ];
  constructor() { }

  ngOnInit() {
  }

}
